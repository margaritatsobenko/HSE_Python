# AST_tree

- Write a function to find the first `n` Fibonacci numbers
- Build the AST of the resulting function
